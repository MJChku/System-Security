#!/bin/sh
sudo chown root  vulnapp
sudo chmod u+s vulnapp
